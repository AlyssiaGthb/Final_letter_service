from pydantic import BaseModel

class LetterPreview(BaseModel):
    letter_content: str

class LetterCreate(BaseModel):
    job_id: int
    letter_content: str