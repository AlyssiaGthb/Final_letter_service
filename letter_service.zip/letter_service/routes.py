from fastapi import APIRouter, HTTPException, Depends, Header, UploadFile, File, Query,Form
from sqlalchemy.orm import Session
from database import get_db
from utils import fetch_job_data, extract_and_structure_cv
from schemas import LetterPreview,LetterCreate
from models import Letter
from utils import verify_user_exists

router = APIRouter()

@router.post("/letter/generate", response_model=LetterPreview)
async def generate_letter(
    job_id: int = Form(...),
    file: UploadFile = File(...),
    authorization: str = Header(...),
    db: Session = Depends(get_db),
):
    try:
        # Lire le contenu du fichier PDF
        file_content = await file.read()

        # Extraire et structurer le CV
        cv_data = extract_and_structure_cv(file_content)

        # Récupérer les données du job
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Invalid token format")
        token = authorization.split(" ")[1]
        job_data = fetch_job_data(job_id, token)

        # Vérifiez que les données sont valides
        if not cv_data or not job_data:
            raise HTTPException(status_code=400, detail="Missing data for letter generation")

        # Génération de la lettre (vous pouvez utiliser un modèle plus sophistiqué ici)
        letter_content = f"""
Cher/Chère {job_data.get('company', 'Responsable du recrutement')},

Je me permets de vous adresser ma candidature pour le poste de {job_data.get('title', 'poste proposé')} au sein de votre entreprise. 
Mes compétences en {', '.join(cv_data.get('skills', []))} correspondent parfaitement aux exigences de ce poste, et je suis très motivé(e) à l'idée de contribuer à {job_data.get('description', 'votre mission')}. 

Je serais ravi(e) de mettre à profit mon expérience et mes connaissances pour participer activement à la réussite de vos projets.

Dans l’attente de votre retour, je reste à votre disposition pour tout complément d’information ou pour convenir d’un entretien.

Je vous prie d’agréer, {job_data.get('company', 'Madame, Monsieur')}, l’expression de mes salutations distinguées.

Cordialement,
{cv_data.get('contact', 'Votre nom complet')}
"""

        return {"letter_content": letter_content.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing the uploaded CV: {e}")


@router.post("/save")
async def save_letter(
    letter: LetterCreate,
    authorization: str = Header(...),  # Récupération du token dans l'en-tête
    db: Session = Depends(get_db),
):
    print(f"Token reçu pour /letter/save : {authorization}")
    user_data = verify_user_exists(authorization)
    user_id = user_data.get("id")

    if not user_id:
        raise HTTPException(status_code=401, detail="Unauthorized")

    try:
        new_letter = Letter(
            user_id=user_id,
            job_id=letter.job_id,
            letter_content=letter.letter_content,
        )
        db.add(new_letter)
        db.commit()
        db.refresh(new_letter)
        return {"message": "Letter saved successfully", "letter_id": new_letter.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save the letter: {e}")