import requests
from fastapi import HTTPException

def fetch_cv_data(cv_id: int, token: str) -> dict:
    headers = {"Authorization": f"Bearer {token}"}
    url = f"http://127.0.0.1:8001/cv/{cv_id}"
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=404, detail=f"Failed to fetch CV data: {e}")

def fetch_job_data(job_id: int, token: str) -> dict:
    headers = {"Authorization": f"Bearer {token}"}
    url = f"http://127.0.0.1:8002/job/{job_id}"
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=404, detail=f"Failed to fetch Job data: {e}")


import pdfplumber
from io import BytesIO

def extract_and_structure_cv(file_bytes):
    """
    Extrait et structure un CV à partir d'un fichier PDF sous forme de bytes.
    """
    try:
        with pdfplumber.open(BytesIO(file_bytes)) as pdf:
            text = "\n".join(page.extract_text() for page in pdf.pages)

        structured_cv = {
            "contact": "",
            "education": [],
            "experience": [],
            "skills": [],
        }

        current_section = None
        for line in text.split("\n"):
            line = line.strip()
            if "Education" in line or "Éducation" in line:
                current_section = "education"
            elif "Experience" in line or "Expérience" in line:
                current_section = "experience"
            elif "Skills" in line or "Compétences" in line:
                current_section = "skills"
            elif current_section:
                structured_cv[current_section].append(line)
            else:
                structured_cv["contact"] += line + " "

        return structured_cv
    except Exception as e:
        raise ValueError(f"Failed to extract and structure CV: {e}")
from fastapi import HTTPException
import requests
from dotenv import load_dotenv
import os

load_dotenv()

AUTH_URL = os.getenv("AUTH_URL")

def verify_user_exists(token: str):
    try:
        headers = {"Authorization": f"Bearer {token}"}
        print(f"Token envoyé à /user-profile : {headers}")
        response = requests.get(f"{AUTH_URL}/user-profile", headers=headers)
        print(f"Réponse de /user-profile : {response.status_code}, {response.text}")
        if response.status_code != 200:
            raise HTTPException(status_code=401, detail="User not found or token invalid")
        return response.json()
    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=500, detail=f"Could not verify user: {e}")
