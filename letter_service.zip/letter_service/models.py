from sqlalchemy import Column, Integer, String, ForeignKey, Text, DateTime
from database import Base
from datetime import datetime

class Letter(Base):
    __tablename__ = "letters"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)  # Références vers un utilisateur
    job_id = Column(Integer, nullable=False)  # Références vers une offre d'emploi
    letter_content = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
